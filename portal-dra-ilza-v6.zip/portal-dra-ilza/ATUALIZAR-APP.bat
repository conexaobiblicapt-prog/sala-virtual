@echo off
echo Sincronizando www com Android...
npx cap sync android
echo Pronto! Gere o APK no Android Studio.
pause
