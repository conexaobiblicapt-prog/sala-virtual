package br.com.drailza.portal;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
