#!/bin/bash
# ── Atualizar o app após editar o HTML ──────────────────────────
echo "🔄 Sincronizando www → Android..."
npx cap sync android
echo "✅ Pronto! Gere o APK no Android Studio."
echo "   Build → Build APK(s)"
