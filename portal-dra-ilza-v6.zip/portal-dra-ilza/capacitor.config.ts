import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'br.com.drailza.portal',
  appName: 'Portal Dra. Ilza',
  webDir: 'www',
  android: {
    allowMixedContent: true,
    backgroundColor: '#FAF7F2',
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 2000,
      backgroundColor: '#FAF7F2',
      androidSplashResourceName: 'splash',
      showSpinner: false,
    },
  },
};

export default config;
