# Portal Dra. Ilza — v6 · Capacitor Android

## Novidades desta versão
- ✅ Cadastro completo de pacientes (nome, e-mail, WhatsApp, CPF, senha)
- ✅ Fluxo: Plano → Dados → Pagamento → Confirmação por e-mail  
- ✅ Chat em tempo real via Firebase Realtime Database
- ✅ Admin vê dados completos de cada paciente (modal com todas as informações)
- ✅ Admin pode ativar acesso manualmente após confirmar pagamento

---

## PRÉ-REQUISITOS

| Ferramenta | Download |
|---|---|
| Node.js 18+ | https://nodejs.org |
| Android Studio | https://developer.android.com/studio |

---

## PASSO A PASSO — GERAR APK

```bash
cd portal-dra-ilza
npm install
npx cap open android
```
No Android Studio: **Build → Build APK(s)** → aguardar → "locate"

---

## CONFIGURAR FIREBASE (obrigatório para chat em tempo real)

### 1. Criar projeto
- Acesse https://console.firebase.google.com
- Clique em "Adicionar projeto" → nome: **portal-dra-ilza**

### 2. Ativar os serviços (no console Firebase):
```
Build → Firestore Database → Criar banco → Modo produção
Build → Realtime Database → Criar banco → Modo produção  
Build → Storage → Começar
```

### 3. Criar app Web
- Configurações do projeto (⚙️) → Seus apps → Web (</>) → Registrar
- Copie o objeto `firebaseConfig` gerado

### 4. Colar no HTML
Abra `www/index.html` e substitua na linha ~37:
```javascript
const firebaseConfig = {
  apiKey:            "SUA_KEY_AQUI",
  authDomain:        "portal-dra-ilza.firebaseapp.com",
  databaseURL:       "https://portal-dra-ilza-default-rtdb.firebaseio.com",
  projectId:         "portal-dra-ilza",
  storageBucket:     "portal-dra-ilza.appspot.com",
  messagingSenderId: "SEU_ID",
  appId:             "SEU_APP_ID"
};
```

### 5. Regras do Firestore (cole no console Firebase → Firestore → Regras):
```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /pacientes/{doc} {
      allow read, write: if true; // Em produção: use autenticação
    }
    match /conteudos/{doc} {
      allow read: if true;
      allow write: if true;
    }
  }
}
```

### 6. Regras do Realtime Database:
```json
{
  "rules": {
    "chats": {
      "$chatId": {
        "mensagens": {
          ".read": true,
          ".write": true
        }
      }
    },
    "sala": {
      ".read": true,
      ".write": true
    }
  }
}
```

---

## CONFIGURAR LINKS DE PAGAMENTO

No `www/index.html`, na função `finalizarCadastro`, substitua:
```javascript
const PAYMENT_LINKS = {
  mp_360:    "https://mpago.la/SEU_LINK_REAL",   // Mercado Pago Plano 360°
  mp_basico: "https://mpago.la/SEU_LINK_REAL",   // Mercado Pago Básico
  ps_360:    "https://pag.ae/SEU_LINK_REAL",     // PagSeguro Plano 360°
  ps_basico: "https://pag.ae/SEU_LINK_REAL",     // PagSeguro Básico
};
```
Como criar: https://www.mercadopago.com.br/cobrar → "Criar link de pagamento"

---

## CONFIGURAR E-MAIL DE CONFIRMAÇÃO

Para enviar o e-mail de confirmação automaticamente, use o **Firebase Functions**:
1. `npm install -g firebase-tools`
2. `firebase init functions`
3. Use o template em `firebase-functions-template/` (incluído no projeto)

Alternativa mais simples: **EmailJS** (grátis até 200 e-mails/mês)
→ https://www.emailjs.com

---

## FLUXO COMPLETO DO PACIENTE

```
1. Acessa → Planos → "Assinar agora"
2. Preenche: nome, e-mail, WhatsApp, CPF, data nascimento, senha
3. Escolhe: Mercado Pago ou PagSeguro
4. É redirecionado para o checkout do gateway
5. Após pagar → recebe e-mail com link de confirmação
6. Clica no link → admin é notificado
7. Admin ativa o acesso (ou automático via webhook)
8. Paciente faz login com e-mail e senha criados
```

## FLUXO DO ADMIN

```
1. Login: admin@drailza.com.br / Ilza@Admin2026
2. Aba "Assinantes" → lista todos os cadastros
3. Clica em qualquer paciente → vê TODOS os dados
4. Botão "Ativar acesso" → libera o login do paciente
5. Aba "Sala" → atende pacientes em tempo real
6. Chat → conversa em tempo real via Firebase
```

---

## ATUALIZAR APP APÓS EDITAR HTML

```bat
ATUALIZAR-APP.bat
```
Depois gere o APK no Android Studio.

---

## CREDENCIAIS DEMO (para testar)

| Tipo | E-mail | Senha |
|---|---|---|
| Admin | admin@drailza.com.br | Ilza@Admin2026 |
| Premium | premium360@drailza.com.br | Ilza@360 |
| Básico | basico@drailza.com.br | Ilza@49 |
